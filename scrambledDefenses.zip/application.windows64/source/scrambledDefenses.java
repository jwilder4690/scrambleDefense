import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class scrambledDefenses extends PApplet {








Minim minim;
AudioPlayer song;
AudioSample keySound, notKeySound, explosion, diffuse;


final String WORD_LENGTH_ERROR = "WORD_LENGTH_ERROR";
final int GAME_START = 0;
final int JUMBLE_MODE = 1;
final int BUILD_MODE = 2;
final int DEFEND_MODE = 3;
final int GAME_OVER = 4;
final int GAME_VICTORY = 5;

Player player;
Town town;
int count = 0;
ArrayList<Word> words = new ArrayList<Word>();
ArrayList<Guess> guesses = new ArrayList<Guess>();
int wordsPerLevel = 60;
int currentLength = 3;
int maxLength = 7;
int gameMode = GAME_START;  
Timer time = new Timer();
boolean[] keys = new boolean[255];
String introMessage = "Your town of Lexico City is under attack! You must unscramble the jamming signal on each incoming bomb to protect your city. Type your best guess and press ENTER to attempt to diffuse.";  

public void setup(){
  
  //size(1080, 720);
  player = new Player();
  town = new Town();
  int randomUpgrade = 0;
  for(int i = 0; i < wordsPerLevel; i++){
    randomUpgrade = round(random(1));
    words.add(new Word(currentLength+randomUpgrade, random(width-120), (-50)*i+100));   
    if(i != 0 && i % 15 == 0){
      currentLength++;
    }
  }
  createAudio();
  //song.loop();
}

public void draw(){
  checkInput(gameMode);
  background(155,155,155);
  switch(gameMode){
    case GAME_START: drawIntroSplash(); break;
    case JUMBLE_MODE: drawGame(); break;
    case GAME_OVER: drawEndSplash(); break;
    case GAME_VICTORY: drawVictorySplash(); break;
  }

  drawHUD();
}

public void keyPressed()
{
  if(key < 255)
  {
    keys[key] = true;
  }
  if(key >= 65 && key <= 90 || key >= 97 && key <= 122){ 
      player.addToGuess(PApplet.parseChar(key));
  }
}

public void keyReleased()
{  
  if(key < 255)
  {
    keys[key] = false;
  }
}

public void checkInput(int mode){
  if(mode == GAME_START){
    if(keys[' '] || keys[ENTER]){
        time.start();
        gameMode = JUMBLE_MODE;
    }
  }
  else if(mode == JUMBLE_MODE){
    if(keys[' ']){
      player.clearGuess();
      keys[' '] = false;
    }
    if(keys[BACKSPACE]){
      player.removeFromGuess();
      keys[BACKSPACE] = false;
    }
    if(keys[ENTER]){
      String finalAnswer = player.getCurrentGuess();
      if(finalAnswer.length() < 3){
        //Too short
      }
      else{
        for(int i = 0; i < words.size(); i++){
          if(words.get(i).checkOnScreen()){
            if(words.get(i).compare(finalAnswer)){
              player.scoreWord(finalAnswer.length());
              guesses.add(new Guess(finalAnswer, i, width/2-100, height-100));
            }
          }
        }
      }
      for(int i = 0; i < maxLength; i++){
        player.removeFromGuess();
      }
      keys[ENTER] = false;
    }
  }
  else if(mode == GAME_OVER){
    if(keys[' '] || keys[ENTER]){
      resetGame();
    }
    keys[' '] = false;
    keys[ENTER] = false;
  }
  else if(mode == GAME_VICTORY){
    if(keys[' '] || keys[ENTER]){
      resetGame();
    }
    keys[' '] = false;
    keys[ENTER] = false;
  }
}

public void drawGame(){
  player.drawGuess();
  town.drawTown();
  for(int i = 0; i < guesses.size(); i++){
    guesses.get(i).drawGuess();
    guesses.get(i).updateGuess();
  }
  count = 0;
  for(int i = 0; i < words.size(); i++){
    words.get(i).drawWord();
    words.get(i).updateWord();
    if(words.get(i).getExploded() || words.get(i).getSolved()){
      println("yep");
      println(words.get(i).getExploded());
      println(words.get(i).getSolved());
      count++;
      if(count == wordsPerLevel && town.getHealth() > 0){
        gameMode = GAME_VICTORY;
      }
    }
  }
}

public void drawIntroSplash(){
  background(0,255,255);
  town.drawTown();
  fill(0,0,0);
  text("Press ENTER to begin",width/2-200, height/2-250);
  text(introMessage, width/2-250, height/2-200, 600, 600);
}

public void drawEndSplash(){
  background(0,0,0);
  fill(255,0,0);
  text("GAME OVER", width/2 - 100, height/2);
  textSize(20);
  text("Press SPACE to restart", width/2-100, height/2+75);
}

public void drawVictorySplash(){
  background(0,255,255);
  fill(0,0,0);
  text("You saved Lexico City!", width/2 - 200, height/2-50);
  textSize(20);
  text("You are a true logophile.", width/2-100, height/2+25);
  text("Press SPACE to restart", width/2-100, height/2+75);
}

public void drawHUD(){
  fill(205,205,205);
  rect(0,0, width, height/8);
  fill(0,0,0);
  textSize(42);
  text("Points: "+player.getPoints(), 50,75);
  text("Lexico City: ", width/2-200, 75);
  text(nf(time.hour(),2)+":"+nf(time.minute(),2)+":"+nf(time.second(),2), width-210, 75);
  noFill();
  stroke(0,255,0);
  rect(width/2+50, 40, 200, 40);
  noStroke();
  fill(0,255,0);
  rect(width/2 +50, 40, town.getHealth(), 40);
}

public void resetGame(){
  gameMode = GAME_START;
  currentLength = 3;
  town.resetTown();
  player.setPoints(0);
  for(int i = 0; i < words.size(); i++){
      words.get(i).generateWord();
      words.get(i).resetWord();
      println(words.get(i).getExploded());
      println(words.get(i).getSolved());
  }
  for(int i = guesses.size()-1; i >= 0; i--){
    guesses.remove(i);
  }
}

public void createAudio(){
  minim = new Minim(this);
  song = minim.loadFile("intro.mp3");
  keySound = minim.loadSample("key.wav");
  notKeySound = minim.loadSample("notKey.wav");
  explosion = minim.loadSample("explosion.wav");
  diffuse = minim.loadSample("diffuse.aiff");
}


class Guess{
  PVector pos;
  PVector target;
  String answer;
  int targetIndex;
  float velocity = 2;
  boolean moving = true;
  
  Guess(String guess, int aim, float x, float y){
    answer = guess;
    targetIndex = aim;
    pos = new PVector(x,y);
  }
  
  public void drawGuess(){
    if(moving){
      fill(0,255,0);
      textSize(50);
      text(answer, pos.x, pos.y);
    }
  }
  
  public void updateGuess(){
    target = words.get(targetIndex).getVector();
    float dist = pos.dist(target);
    PVector direction = PVector.sub(target,pos);
    direction.normalize();
    
    pos.add(direction.mult(velocity)); 
    if(pos.dist(target) < velocity && !words.get(targetIndex).getSolved()){
      words.get(targetIndex).setSolved();
      moving = false;
    }
  }
  
}
class Player{
  int points;
  char[] currentGuess; 
  int guessIndex;
  
  Player(){
    points = 0;
    currentGuess = new char[7];
    guessIndex = 0;
  }
  
  public String getCurrentGuess(){
    String guess = new String(currentGuess).substring(0,guessIndex);
    return guess;
  }
  
  public int getGuessIndex(){
    return guessIndex;
  }
  
  public int getPoints(){
    return points;
  }
  
  public void setPoints(int value){
    points = value;
  }
  
  public void scoreWord(int size){
    int score = 0;
    switch(size){
      case 3: score = 50; break;
      case 4: score = 100; break;
      case 5: score = 200; break;
      case 6: score = 400; break;
      case 7: score = 1000; break;
      default: break;
    }
    points += score;
  }
  
  public void addToGuess(char guess){
    keySound.trigger(); 
    if(guessIndex < maxLength-1){
      currentGuess[guessIndex] = guess;
      guessIndex++;
    }
    else{
      currentGuess[guessIndex] = guess;
    }
  }
  
  public void clearGuess(){
    for(int i = 0; i < currentGuess.length; i++){
      currentGuess[i] = Character.MIN_VALUE;
    }
    guessIndex = 0;
  }
  
  public void removeFromGuess(){
    currentGuess[guessIndex] = Character.MIN_VALUE;
    if(guessIndex > 0){
      guessIndex--;
    }
    currentGuess[guessIndex] = Character.MIN_VALUE;
  }
  
  public void drawGuess(){
    fill(0,0,0);
    textSize(50);
    text(new String(currentGuess), width/2-100, height-100);
  }
  
}
class Timer {
  int startTime = 0, stopTime = 0;
  boolean running = false;
  
    
  public void start() 
  {
    startTime = millis();
    running = true;
  }
  public void stop() 
  {
    stopTime = millis();
    running = false;
  }
  
  public int getRemainingTime() 
  {
    int elapsed;
    if (running) 
    {
      elapsed = (millis() - startTime);
    }
    else 
    {
      elapsed = (stopTime - startTime);
    }
    return elapsed;
  }
  
  
  public int hundredth()
  {
    return (getRemainingTime() / 10) % 100;
  }
  
  public int second()
  {
    return (getRemainingTime() / 1000) % 60;
  }
  
  public int minute() 
  {
    return (getRemainingTime() / (1000*60)) % 60;
  }
  
  public int hour()
  {
    return (getRemainingTime() / (1000*60*60)) % 24;
  }
  
  public boolean isRunning()
  {
    return running;
  }
}
class Town{
  int health;
  int startingHealth;
  int damage = 25;
  Building[] buildings = new Building[20];
  boolean destroyed = false;
  
  
  Town(){
    startingHealth = 205;
    health = startingHealth;
    generateTown();
  }
  
  public void takeDamage(){
    health -= damage;
    explosion.trigger();
    if(health < 0){
      health = 0;
      destroyed = true;
      gameMode = GAME_OVER;
      time.stop();
    }
  }
  
  public int getHealth(){
    return health;
  }
  
  public void resetTown(){
    health = startingHealth;
  }
  
  public void generateTown(){
    float averageWidth = width/buildings.length;
    for(int i = 0; i < buildings.length; i++){
      buildings[i] = new Building(averageWidth*i+random(-50,50), PApplet.parseFloat(height), averageWidth+random(-averageWidth/2,averageWidth/2), random(50,100));
    }
  }
  
  public void drawTown(){
    fill(75,75,75);
    rect(0, height-10, width, 10);
    for(int i = 0; i < buildings.length; i++){
      buildings[i].drawBuilding();
    }
  }
}

class Building{
  final int windowSpace = 25;
  float x;
  float y;
  float wide;
  float tall;
  
  Building(float x, float y, float w, float h){   //{x, y} is bottom left
    this.x = x;
    this.y = y;
    this.wide = w;
    this.tall = h;
  }
  
  public void drawBuilding(){
    noStroke();
    fill(75,75,75);
    rect(x, y-tall, wide, tall);
    
    int cols = PApplet.parseInt(wide)/windowSpace;
    int rows = PApplet.parseInt(tall)/windowSpace;
    
    for(int i = 0; i < cols; i++){
      for(int j = 0; j < rows; j++){
        if(i % 2 != 0 && j % 2 != 0 && PApplet.parseInt(x) % 2 == 0){
          fill(75,75,75);
        }
        else if(i % 2 == 0 && j % 2 == 0 && PApplet.parseInt(x) % 2 != 0){
          fill(75,75,75);
        }
        else{
          fill(255,255,51);
        }
        rect(x+(i*windowSpace)+10, y-(j*windowSpace)-25, 10, 10);
      }
    }
  }
}
class Word{
  final float FALL_SPEED = .2f;
  
  String[] threeLetterWords = new String[1044];
  String[] fourLetterWords = new String[4268];
  String[] fiveLetterWords = new String[9320];
  String[] sixLetterWords = new String[15762];
  String[] sevenLetterWords = new String[22247];
  
  String currentWord = "";
  int currentLength;
  char[] scrambledWord;
  //ArrayList wordsGuessed = new ArrayList<String>();
  float xPos;
  float yPos;
  float yStart;
  boolean onScreen = false;
  boolean solved = false;
  boolean exploded = false;
  int fade = 255;
  float explosionSize;
  
  Word(int size, float x, float y){
    xPos = x;
    yPos = y;
    yStart = y;
    currentLength = size;
    explosionSize = random(70,200);
    loadWords("threeLetterWords.txt", threeLetterWords);
    loadWords("fourLetterWords.txt", fourLetterWords);
    loadWords("fiveLetterWords.txt", fiveLetterWords);
    loadWords("sixLetterWords.txt", sixLetterWords);
    loadWords("sevenLetterWords.txt", sevenLetterWords);
    generateWord();
  }
  
  public void generateWord(){
    switch(currentLength){
      case 3: currentWord = threeLetterWords[PApplet.parseInt(random(threeLetterWords.length))]; break;
      case 4: currentWord = fourLetterWords[PApplet.parseInt(random(fourLetterWords.length))]; break;
      case 5: currentWord = fiveLetterWords[PApplet.parseInt(random(fiveLetterWords.length))]; break;
      case 6: currentWord = sixLetterWords[PApplet.parseInt(random(sixLetterWords.length))]; break;
      case 7: currentWord = sevenLetterWords[PApplet.parseInt(random(sevenLetterWords.length))]; break;
      default: currentWord = WORD_LENGTH_ERROR; 
    }
      scrambledWord = scrambleWord(currentWord); 
  }
  
  public void loadWords(String file, String[] list){
    try{
      BufferedReader reader = createReader(file);
      for(int i = 0; i < list.length; i++){
        list[i] = reader.readLine();
      }
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
  
  public PVector getVector(){
    return new PVector(xPos,yPos);
  }
  
  public char[] getScrambledWord(){
    return scrambledWord;
  }
  
  public boolean getExploded(){
    return exploded;
  }

  public char[] scrambleWord(String inWord){   //Fisher-Yates Shuffle
    char[] pieces = inWord.toCharArray();
    for(int i = pieces.length-1; i > 0; i--){
      int index = PApplet.parseInt(random(i+1));
      char temp = pieces[index];
      pieces[index] = pieces[i];
      pieces[i] = temp;
    }
    return pieces;
  }
  
  public void setSolved(){
    solved = true;
    diffuse.trigger();
  }
  
  public boolean getSolved(){
    return solved;
  }

  public void resetWord(){
    yPos = yStart;
    exploded = false;
    solved = false;
  }
  
  public boolean compare(String answer){
    if(currentWord.equals(answer)){
      return true;
    }
    return false;
  }
  
  public boolean checkOnScreen(){
    return onScreen;
  }
  
  public void drawWord(){
    if(solved){
      fill(0,255,0, fade);
      text(currentWord, xPos, yPos);
    }
    else if(exploded){
      fill(255,55,0, fade);
      ellipse(xPos+explosionSize/2, yPos, explosionSize, explosionSize);
      fade -= 3;
    }
    else{
      fill(0,0,0);
      text(new String(scrambledWord), xPos, yPos);
    }
  }
  
  public void updateWord(){
    yPos += FALL_SPEED;
    if(yPos > 0){
      onScreen = true;
    }
    if(yPos > height-20 && !solved && !exploded){
      town.takeDamage();
      exploded = true;
    }
    if(solved){
      fade--;
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#000000", "--stop-color=#cccccc", "scrambledDefenses" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
